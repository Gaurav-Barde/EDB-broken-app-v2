export const Table = () => {
  return <div>Implement me!</div>;
};
